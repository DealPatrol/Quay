THE CELESTIAL DREAMS COLLECTION — 30 SVG Designs
==================================================

CONTENTS
--------
This bundle contains 30 original celestial line-art SVG files:

  Zodiac Glyphs (12)
    01. Aries — The Ram
    02. Taurus — The Bull
    03. Gemini — The Twins
    04. Cancer — The Crab
    05. Leo — The Lion
    06. Virgo — The Maiden
    07. Libra — The Scales
    08. Scorpio — The Scorpion
    09. Sagittarius — The Archer
    10. Capricorn — The Sea-Goat
    11. Aquarius — The Water Bearer
    12. Pisces — The Fish

  Moons (6)
    01. Slim Crescent & Stars
    02. Bold Crescent Rising
    03. Full Moon & Craters
    04. Moon Phase Row
    05. Crescent Halo
    06. Moon Behind Clouds

  Constellations (4)
    01. Big Dipper
    02. Orion the Hunter
    03. Cassiopeia
    04. Lyra the Harp

  Suns (4)
    01. Radiant Sun
    02. Retro Half Sun
    03. Geometric Sun
    04. Minimal Sun

  Evil Eyes (2)
    01. Evil Eye Talisman
    02. Radiant Evil Eye

  Stars (2)
    01. Sparkle Cluster
    02. Shooting Star

QUICK START — CRICUT (Design Space)
-----------------------------------
1. Upload > Upload Image > Browse > select an SVG file.
2. The design appears as cut lines. Size it on your canvas (designs are
   square; keep the lock on to preserve proportions).
3. For vinyl/paper: choose your material and cut as usual. The lines are
   clean single strokes, so weeding is easy.
4. For Print Then Cut: add an offset/background shape behind the line art,
   flatten, then print.

TIP: The artwork is black line art. To cut in a different color, just change
the material color — or in Design Space, use Contour/Ungroup as needed. To
make the lines thicker for small decals, add a small Offset.

QUICK START — SILHOUETTE (Studio)
---------------------------------
1. File > Open > select an SVG (Designer Edition or higher opens SVG directly;
   with Basic Edition, open in a browser, copy, and paste into Studio, or use
   the free SVG-to-DXF conversion in your browser first).
2. Resize by dragging a corner handle (hold Shift for proportions).
3. Send > choose material > adjust blade settings > Send.
4. For Print & Cut: draw a weeding box or offset around the design, group,
   and add registration marks.

QUICK START — ADOBE ILLUSTRATOR
--------------------------------
1. File > Open > select an SVG.
2. Everything is vector: use the Direct Selection tool to tweak any line.
3. Recolor: select artwork, then Object > Expand, or simply apply a new stroke
   color in the Stroke panel (all art uses strokes, not fills).
4. Scale freely — vector art stays crisp at any size.
5. Save/Export: File > Export > Export As > PNG/SVG/PDF as needed.

ZODIAC TIP
----------
The 12 zodiac glyphs come inside thin badge frames — perfect as-is for
stickers, shirt chest prints, and mug decals. To use a glyph without the
frame, open the SVG in Illustrator or Inkscape and delete the outer circle.

QUESTIONS?
----------
Contact us through your Quay store account — we're happy to help.

© 2026 Quay. See LICENSE.txt for commercial use terms.
