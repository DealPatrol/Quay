THE BOHO LINE ART COLLECTION — 54 SVG Designs
==================================================

CONTENTS
--------
This bundle contains 54 original boho line-art SVG files:

  Faces & Portraits (0)

  Botanicals (0)

  Celestial (0)

  Abstract & Arches (0)

  Quote Typography (0)

QUICK START — CRICUT (Design Space)
-----------------------------------
1. Upload > Upload Image > Browse > select an SVG file.
2. The design appears as cut lines. Size it on your canvas (designs are
   square; keep the lock on to preserve proportions).
3. For vinyl/paper: choose your material and cut as usual. The lines are
   clean single strokes, so weeding is easy.
4. For Print Then Cut: add an offset/background shape behind the line art,
   flatten, then print.

TIP: The artwork is black line art. To cut in a different color, just change
the material color — or in Design Space, use Contour/Ungroup as needed. To
make the lines thicker for small decals, add a small Offset.

QUICK START — SILHOUETTE (Studio)
---------------------------------
1. File > Open > select an SVG (Designer Edition or higher opens SVG directly;
   with Basic Edition, open in a browser, copy, and paste into Studio, or use
   the free SVG-to-DXF conversion in your browser first).
2. Resize by dragging a corner handle (hold Shift for proportions).
3. Send > choose material > adjust blade settings > Send.
4. For Print & Cut: draw a weeding box or offset around the design, group,
   and add registration marks.

QUICK START — ADOBE ILLUSTRATOR
--------------------------------
1. File > Open > select an SVG.
2. Everything is vector: use the Direct Selection tool to tweak any line.
3. Recolor: select artwork, then Object > Expand, or simply apply a new stroke
   color in the Stroke panel (all art uses strokes, not fills).
4. Scale freely — vector art stays crisp at any size.
5. Save/Export: File > Export > Export As > PNG/SVG/PDF as needed.

FONTS NOTE
----------
The 10 quote designs use common serif/sans-serif system fonts
(Georgia/Times/Arial/Helvetica) and will render in any browser or design app.
For pixel-perfect results in Cricut/Silhouette, convert text to outlines in
Illustrator (Type > Create Outlines) or Inkscape (Path > Object to Path)
before cutting.

QUESTIONS?
----------
Contact us through your Quay store account — we're happy to help.

© 2026 Quay. See LICENSE.txt for commercial use terms.
